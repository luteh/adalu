package com.rekret.adalu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
